<?php
session_start();
$_SESSION['commandes'] = $_POST;

$foodPrice = [
    "burger" => 12,
    "pizza" => 20,
    "pokebowl" => 15
];

foreach($foodPrice as $key => $value) {

    if($key == $_POST['food']) {
        $totalCommandes = $_POST["quantity"] * $value; 
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recap</title>
</head>
<body>
    <?php require_once 'menu.php' ?>
    <h1>Récapitulatif de la commande</h1>
    <p>Voici les articles que vous souhaitez commander</p>
    <br>
    <?php echo "Vous avez pris" . " " . $_POST['quantity'] . " " . $_POST['food'] . " " . $totalCommandes . " " . "€" ; ?>
    <br>
    <a href="accueil.php"> Passez une nouvelle commande</a>


<?php require_once 'footer.php' ?>
</body>
</html>