
<footer>
        <h3>Hubert Manger &copy;</h3>
    </footer>

   
