<?php

session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page d'accueil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <?php require_once 'menu.php' ?>
    

    <h1> Bienvenue !</h1>
    <h2>Sélectionner votre commande !</h2>
    <form action="recap.php" method="POST">

    <input type="radio" id="burger" name="food" value="burger"> 
    <label for="burger"> : Burger (12€) </label> <br>

    <input type="radio" id="pizza" name="food" value="pizza">
    <label for="pizza"> : Pizza (20€) </label> <br>
    
    <input type="radio" id="pokebowl" name="food" value="pokebowl">
    <label for="pokebowl"> : Pokébowl (15€) </label> <br>

    <input type="number" name="quantity" placeholder= "Quantité" required>

    <input type="submit" value="Confirmer la commande ! ">

    </form>
    <?php require_once 'footer.php' ?>

</body>
</html>