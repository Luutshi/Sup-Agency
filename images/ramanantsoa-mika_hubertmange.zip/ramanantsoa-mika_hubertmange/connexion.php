<?php
session_start()

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
</head>
<body>
    <?php require_once 'menu.php' ?>
    <form action="" method="POST">
        <?php
            if(isset($_POST['username']) && isset($_POST['password'])) {
                if($_POST['username'] === "hubert" && $_POST['password'] === "mange") {
                    $_SESSION['user'] = $_POST;
                    header("location: accueil.php");
                    exit;
                }
            }
            ?>
                <label for="username"> Identifiant : </label>
                <input type="text" id="username" name="username"> <br>
                <label for="password"> Mot de passe : </label>
                <input type="password" id="password" name="password"> <br>
                <input type="submit" value="Se connecter">
        
    </form>
    <?php require_once 'footer.php' ?>

</body>
</html>
