<header>
    <nav>
        <ul>
            <li><a href="accueil.php">Accueil</a></li>
            <?php
            
            if (isset($_SESSION['users'])) {
                if ($_SESSION['users']['username'] === "hubert") {
                    echo("  <li><a href='deconnexion.php'>Se déconnecter</a></li>
                            <li><a href='commandes.php'>Commandes</a></li>
                            <li><a href='confirmationDeleteData.php'>Supprimer les données</a></li>");
                } else {
                    echo("<li><a href='connexion.php'>Se connecter</a></li>");
                }
            } else {
                echo("<li><a href='connexion.php'>Se connecter</a></li>");
            }

            ?>
        </ul>
    </nav>
</header>